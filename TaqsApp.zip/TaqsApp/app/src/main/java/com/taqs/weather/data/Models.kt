package com.taqs.weather.data

import java.util.Locale

// ---------------------------------------------------------------------------
// DTOs returned by Open-Meteo (all numbers are Double? for resilience)
// ---------------------------------------------------------------------------

data class ForecastResponse(
    val current: CurrentDto?,
    val hourly: HourlyDto?,
    val daily: DailyDto?
)

data class CurrentDto(
    val time: String?,
    val temperature_2m: Double?,
    val relative_humidity_2m: Double?,
    val apparent_temperature: Double?,
    val is_day: Double?,
    val precipitation: Double?,
    val weather_code: Double?,
    val cloud_cover: Double?,
    val pressure_msl: Double?,
    val wind_speed_10m: Double?,
    val wind_direction_10m: Double?,
    val wind_gusts_10m: Double?
)

data class HourlyDto(
    val time: List<String>?,
    val temperature_2m: List<Double?>?,
    val precipitation_probability: List<Double?>?,
    val weather_code: List<Double?>?,
    val wind_speed_10m: List<Double?>?,
    val is_day: List<Double?>?
)

data class DailyDto(
    val time: List<String>?,
    val weather_code: List<Double?>?,
    val temperature_2m_max: List<Double?>?,
    val temperature_2m_min: List<Double?>?,
    val sunrise: List<String?>?,
    val sunset: List<String?>?,
    val uv_index_max: List<Double?>?,
    val precipitation_sum: List<Double?>?,
    val precipitation_probability_max: List<Double?>?,
    val wind_speed_10m_max: List<Double?>?
)

data class AirResponse(val current: AirCurrentDto?)

data class AirCurrentDto(
    val european_aqi: Double?,
    val pm2_5: Double?,
    val pm10: Double?,
    val dust: Double?
)

data class GeoResponse(val results: List<GeoResult>?)

data class GeoResult(
    val id: Long?,
    val name: String?,
    val latitude: Double?,
    val longitude: Double?,
    val country: String?,
    val admin1: String?
)

// ---------------------------------------------------------------------------
// Domain models used by the app (also serialized to the offline cache)
// ---------------------------------------------------------------------------

data class Place(
    val name: String,
    val country: String = "",
    val lat: Double,
    val lon: Double,
    val isGps: Boolean = false
) {
    val key: String get() = String.format(Locale.US, "%.2f,%.2f", lat, lon)
}

data class CurrentWeather(
    val time: String,
    val temp: Double,
    val feelsLike: Double,
    val humidity: Int,
    val code: Int,
    val isDay: Boolean,
    val cloud: Int,
    val pressure: Double,
    val wind: Double,
    val windDir: Int,
    val gusts: Double,
    val precipitation: Double
)

data class HourPoint(
    val time: String,
    val temp: Double,
    val pop: Int,
    val code: Int,
    val isDay: Boolean,
    val wind: Double
)

data class DayPoint(
    val date: String,
    val code: Int,
    val max: Double,
    val min: Double,
    val sunrise: String,
    val sunset: String,
    val uv: Double,
    val rainSum: Double,
    val pop: Int,
    val windMax: Double
)

data class AirQuality(
    val aqi: Int?,
    val pm25: Double?,
    val pm10: Double?,
    val dust: Double?
)

data class WeatherBundle(
    val place: Place,
    val current: CurrentWeather,
    val hourly: List<HourPoint>,
    val daily: List<DayPoint>,
    val air: AirQuality?,
    val tempUnit: String,   // "c" | "f"
    val windUnit: String,   // "kmh" | "mph" | "ms"
    val fetchedAt: Long
)

data class Settings(
    val tempUnit: String = "c",
    val windUnit: String = "kmh",
    val theme: String = "system",   // system | light | dark
    val lang: String = "ar",        // ar | en
    val notifEnabled: Boolean = false,
    val notifHour: Int = 7,
    val alertsEnabled: Boolean = true
)
