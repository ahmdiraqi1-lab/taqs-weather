package com.taqs.weather.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.taqs.weather.data.Settings
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Scheduler {
    private const val DAILY = "daily_summary"
    private const val ALERTS = "weather_alerts"

    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun sync(ctx: Context, s: Settings) {
        val wm = WorkManager.getInstance(ctx)

        if (s.notifEnabled) {
            val now = LocalDateTime.now()
            var target = now.withHour(s.notifHour).withMinute(0).withSecond(0).withNano(0)
            if (!target.isAfter(now)) target = target.plusDays(1)
            val delay = Duration.between(now, target).toMinutes()
            val req = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .setConstraints(net)
                .build()
            // UPDATE so a changed hour takes effect immediately
            wm.enqueueUniquePeriodicWork(DAILY, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork(DAILY)
        }

        if (s.alertsEnabled) {
            val req = PeriodicWorkRequestBuilder<AlertWorker>(3, TimeUnit.HOURS)
                .setConstraints(net)
                .build()
            wm.enqueueUniquePeriodicWork(ALERTS, ExistingPeriodicWorkPolicy.KEEP, req)
        } else {
            wm.cancelUniqueWork(ALERTS)
        }
    }
}
