package com.taqs.weather

import android.app.Application
import com.taqs.weather.work.Notifier

class TaqsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
    }
}
