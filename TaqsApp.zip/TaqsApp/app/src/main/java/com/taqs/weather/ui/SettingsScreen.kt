package com.taqs.weather.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.taqs.weather.data.Settings

@Composable
fun SettingsScreen(
    s: Settings,
    t: T,
    onTemp: (String) -> Unit,
    onWind: (String) -> Unit,
    onTheme: (String) -> Unit,
    onLang: (String) -> Unit,
    onDaily: (Boolean) -> Unit,
    onHour: (Int) -> Unit,
    onAlerts: (Boolean) -> Unit,
    askNotifPermission: (then: () -> Unit) -> Unit
) {
    var hourDialog by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(t.settings, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Section(t.units)
        Label(t.temperature)
        Chips(listOf("c" to "°C", "f" to "°F"), s.tempUnit, onTemp)
        Label(t.windSpeed)
        Chips(listOf("kmh" to t.windUnitLabel("kmh"), "ms" to "m/s", "mph" to "mph"), s.windUnit, onWind)

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Section(t.appearance)
        Chips(listOf("system" to t.themeSystem, "light" to t.themeLight, "dark" to t.themeDark), s.theme, onTheme)
        Label(t.language)
        Chips(listOf("ar" to t.arabic, "en" to t.english), s.lang, onLang)

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Section(t.notifications)
        SwitchRow(t.dailyNotif, null, s.notifEnabled) { on ->
            if (on) askNotifPermission { onDaily(true) } else onDaily(false)
        }
        if (s.notifEnabled) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(t.dailyNotifTime)
                TextButton(onClick = { hourDialog = true }) { Text("%02d:00".format(s.notifHour)) }
            }
        }
        SwitchRow(t.alertsNotif, t.alertsDesc, s.alertsEnabled) { on ->
            if (on) askNotifPermission { onAlerts(true) } else onAlerts(false)
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Section(t.about)
        Text(t.aboutText, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (hourDialog) {
        AlertDialog(
            onDismissRequest = { hourDialog = false },
            confirmButton = { TextButton(onClick = { hourDialog = false }) { Text("OK") } },
            title = { Text(t.dailyNotifTime) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    (0..23).forEach { h ->
                        TextButton(onClick = { onHour(h); hourDialog = false }, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                "%02d:00".format(h),
                                fontWeight = if (h == s.notifHour) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun Section(text: String) =
    Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))

@Composable
private fun Label(text: String) = Text(text, modifier = Modifier.padding(top = 4.dp))

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, label) ->
            FilterChip(selected = selected == k, onClick = { onPick(k) }, label = { Text(label) })
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
