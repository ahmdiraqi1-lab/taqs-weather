package com.taqs.weather

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.taqs.weather.ui.HomeScreen
import com.taqs.weather.ui.PlacesScreen
import com.taqs.weather.ui.SettingsScreen
import com.taqs.weather.ui.T
import com.taqs.weather.ui.TaqsTheme
import com.taqs.weather.work.Notifier
import com.taqs.weather.work.Scheduler

class MainActivity : ComponentActivity() {

    private val vm: com.taqs.weather.ui.MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val st by vm.state.collectAsStateWithLifecycle()
            val t = remember(st.settings.lang) { T(st.settings.lang) }
            val dir = if (st.settings.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

            TaqsTheme(st.settings.theme) {
                CompositionLocalProvider(LocalLayoutDirection provides dir) {
                    Root(st, t)
                }
            }
        }
    }

    @Composable
    private fun Root(st: com.taqs.weather.ui.UiState, t: T) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        val snack = remember { SnackbarHostState() }

        // ---- location permission -------------------------------------------
        val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r.values.any { it }) vm.useGps() else vm.onLocationDenied()
        }
        fun requestGps() {
            val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
            if (ok) vm.useGps()
            else locLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
            )
        }

        // ---- notification permission ---------------------------------------
        var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) pending?.invoke() else vm.showMessage(t.permNeeded)
            pending = null
        }
        fun askNotif(then: () -> Unit) {
            if (Build.VERSION.SDK_INT >= 33 && !Notifier.canPost(this)) {
                pending = then
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else then()
        }

        LaunchedEffect(st.message) {
            st.message?.let { snack.showSnackbar(it); vm.consumeMessage() }
        }

        // first launch: no place yet → jump to the places tab
        LaunchedEffect(st.ready, st.place) {
            if (st.ready && st.place == null) tab = 0
        }

        // keep background work in sync with saved settings
        LaunchedEffect(st.settings.notifEnabled, st.settings.alertsEnabled, st.settings.notifHour) {
            if (st.ready) Scheduler.sync(applicationContext, st.settings)
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Filled.Home, null) }, label = { Text(t.home) }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Filled.LocationCity, null) }, label = { Text(t.places) }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(t.settings) }
                    )
                }
            }
        ) { pad ->
            Surface(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
                when (tab) {
                    0 -> HomeScreen(
                        st = st, t = t,
                        onRefresh = vm::refresh,
                        onGps = ::requestGps,
                        onToggleFav = { st.place?.let(vm::toggleFavorite) },
                        onPickCity = { tab = 1 }
                    )
                    1 -> PlacesScreen(
                        st = st, t = t,
                        onSearch = vm::search,
                        onSelect = { vm.selectPlace(it); tab = 0 },
                        onToggleFav = vm::toggleFavorite,
                        onGps = { requestGps(); tab = 0 }
                    )
                    else -> SettingsScreen(
                        s = st.settings, t = t,
                        onTemp = { vm.setTemp(it) }, onWind = { vm.setWind(it) },
                        onTheme = { vm.setTheme(it) }, onLang = { vm.setLang(it) },
                        onDaily = { vm.setDaily(it) }, onHour = { vm.setDailyHour(it) },
                        onAlerts = { vm.setAlerts(it) },
                        askNotifPermission = ::askNotif
                    )
                }
            }
        }
    }
}
