package com.taqs.weather.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taqs.weather.data.DayPoint
import com.taqs.weather.data.WeatherBundle
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Glass = Color(0x26FFFFFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    st: UiState,
    t: T,
    onRefresh: () -> Unit,
    onGps: () -> Unit,
    onToggleFav: () -> Unit,
    onPickCity: () -> Unit
) {
    val b = st.bundle
    val place = st.place

    if (place == null) {
        EmptyHome(t, onGps, onPickCity)
        return
    }

    val bg = if (b != null) WeatherInfo.gradient(b.current.code, b.current.isDay)
    else WeatherInfo.gradient(2, true)

    Box(Modifier.fillMaxSize().background(bg)) {
        PullToRefreshBox(isRefreshing = st.loading && b != null, onRefresh = onRefresh) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // ---- header -----------------------------------------------
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(place?.name ?: "", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        if (!place?.country.isNullOrBlank())
                            Text(place!!.country, color = Color(0xCCFFFFFF), fontSize = 13.sp)
                    }
                    IconButton(onClick = onGps) {
                        Icon(Icons.Filled.MyLocation, t.useGps, tint = Color.White)
                    }
                    val isFav = st.favorites.any { it.key == place?.key }
                    IconButton(onClick = onToggleFav) {
                        Icon(
                            if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            if (isFav) t.removeFav else t.addFav,
                            tint = if (isFav) Color(0xFFFF6B81) else Color.White
                        )
                    }
                }

                if (st.loading && b == null) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(t.loading, color = Color.White, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }

                if (st.error && b == null) {
                    Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📡", fontSize = 56.sp)
                        Text(t.errorLoad, color = Color.White, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onRefresh) { Text(t.retry) }
                    }
                }

                if (st.offline) {
                    Text(
                        t.offline, color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .background(Color(0x66FF9800)).padding(8.dp),
                        textAlign = TextAlign.Center
                    )
                }

                if (b != null) WeatherContent(b, t)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun EmptyHome(t: T, onGps: () -> Unit, onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(WeatherInfo.gradient(0, true)).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("⛅", fontSize = 84.sp)
        Spacer(Modifier.height(12.dp))
        Text(t.noPlace, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGps, modifier = Modifier.fillMaxWidth()) { Text(t.useGps) }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Text(t.search) }
    }
}

@Composable
private fun WeatherContent(b: WeatherBundle, t: T) {
    val c = b.current
    val lang = t.lang
    val sym = t.tempSym(b.tempUnit)
    val wu = t.windUnitLabel(b.windUnit)
    val today = b.daily.firstOrNull()

    // ---- hero ---------------------------------------------------------------
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(WeatherInfo.emoji(c.code, c.isDay), fontSize = 76.sp)
        Text("${c.temp.roundToInt()}°", color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light)
        Text(WeatherInfo.describe(c.code, lang), color = Color.White, fontSize = 20.sp)
        if (today != null) {
            Text(
                "${t.high} ${today.max.roundToInt()}°  •  ${t.low} ${today.min.roundToInt()}°  •  ${t.feelsLike} ${c.feelsLike.roundToInt()}°",
                color = Color(0xE6FFFFFF), fontSize = 14.sp
            )
        }
    }

    // ---- tips ---------------------------------------------------------------
    val tips = buildTips(b, t)
    if (tips.isNotEmpty()) {
        Card(t.tips) {
            tips.forEach { Text(it, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp)) }
        }
    }

    // ---- hourly -------------------------------------------------------------
    Card(t.hourly) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(b.hourly) { h ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(hourLabel(h.time, t, h === b.hourly.first()), color = Color(0xCCFFFFFF), fontSize = 12.sp)
                    Text(WeatherInfo.emoji(h.code, h.isDay), fontSize = 26.sp, modifier = Modifier.padding(vertical = 4.dp))
                    Text("${h.temp.roundToInt()}°", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (h.pop >= 10) "💧${h.pop}%" else " ",
                        color = Color(0xFF9FD8FF), fontSize = 11.sp
                    )
                }
            }
        }
    }

    // ---- 15 days ------------------------------------------------------------
    val gMin = b.daily.minOfOrNull { it.min } ?: 0.0
    val gMax = b.daily.maxOfOrNull { it.max } ?: 1.0
    Card(t.daily15) {
        b.daily.forEachIndexed { i, d -> DayRow(d, i, gMin, gMax, t) }
    }

    // ---- details ------------------------------------------------------------
    Card(t.details) {
        DetailRow("💧 ${t.humidity}", "${c.humidity}%")
        DetailRow("💨 ${t.wind}", "${c.wind.roundToInt()} $wu ${t.compass(c.windDir)}")
        DetailRow("🌬️ ${t.gusts}", "${c.gusts.roundToInt()} $wu")
        DetailRow("🧭 ${t.pressure}", "${c.pressure.roundToInt()} hPa")
        DetailRow("☁️ ${t.cloud}", "${c.cloud}%")
        if (today != null) {
            DetailRow("☀️ ${t.uv}", "${today.uv.roundToInt()} — ${t.uvLabel(today.uv)}")
            DetailRow("🌧️ ${t.rain}", "${"%.1f".format(Locale.US, today.rainSum)} mm")
            DetailRow("🌅 ${t.sunrise}", clock(today.sunrise))
            DetailRow("🌇 ${t.sunset}", clock(today.sunset))
        }
    }

    // ---- air ----------------------------------------------------------------
    b.air?.let { a ->
        Card(t.airQuality) {
            DetailRow("AQI", "${a.aqi ?: "—"} — ${t.aqiLabel(a.aqi)}")
            a.pm25?.let { DetailRow("PM2.5", "${"%.1f".format(Locale.US, it)} µg/m³") }
            a.pm10?.let { DetailRow("PM10", "${"%.1f".format(Locale.US, it)} µg/m³") }
            a.dust?.let { DetailRow(if (lang == "ar") "الغبار" else "Dust", "${"%.1f".format(Locale.US, it)} µg/m³") }
        }
    }

    Text(
        "${t.updated}: ${SimpleDateFormat("HH:mm", Locale.US).format(Date(b.fetchedAt))}  •  ${t.aboutText}",
        color = Color(0x99FFFFFF), fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Glass).padding(16.dp)
    ) {
        Text(title, color = Color(0xCCFFFFFF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xE6FFFFFF), fontSize = 14.sp)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DayRow(d: DayPoint, index: Int, gMin: Double, gMax: Double, t: T) {
    val date = runCatching { LocalDate.parse(d.date) }.getOrNull()
    val name = when {
        index == 0 -> t.today
        index == 1 -> t.tomorrow
        date != null -> t.weekday(date.dayOfWeek.value)
        else -> d.date
    }
    val sub = date?.let { "${it.dayOfMonth} ${t.month(it.monthValue)}" } ?: ""

    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.width(78.dp)) {
            Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color(0x99FFFFFF), fontSize = 11.sp)
        }
        Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(WeatherInfo.emoji(d.code), fontSize = 22.sp)
            Text(if (d.pop >= 10) "${d.pop}%" else "", color = Color(0xFF9FD8FF), fontSize = 10.sp)
        }
        Text("${d.min.roundToInt()}°", color = Color(0xCCFFFFFF), modifier = Modifier.width(36.dp), textAlign = TextAlign.Center)
        // temperature range bar
        val span = (gMax - gMin).coerceAtLeast(1.0)
        val startF = ((d.min - gMin) / span).toFloat().coerceIn(0f, 1f)
        val endF = ((d.max - gMin) / span).toFloat().coerceIn(startF, 1f)
        Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
            Row(Modifier.fillMaxSize()) {
                if (startF > 0f) Spacer(Modifier.weight(startF))
                Box(
                    Modifier.weight((endF - startF).coerceAtLeast(0.04f)).fillMaxSize()
                        .clip(RoundedCornerShape(3.dp)).background(Color(0xFFFFC857))
                )
                if (1f - endF > 0f) Spacer(Modifier.weight(1f - endF))
            }
        }
        Text("${d.max.roundToInt()}°", color = Color.White, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(36.dp), textAlign = TextAlign.Center)
    }
}

private fun buildTips(b: WeatherBundle, t: T): List<String> {
    val out = mutableListOf<String>()
    val today = b.daily.firstOrNull()
    // normalise to °C for thresholds
    fun c(v: Double) = if (b.tempUnit == "f") (v - 32) * 5 / 9 else v
    fun kmh(v: Double) = when (b.windUnit) { "mph" -> v * 1.609; "ms" -> v * 3.6; else -> v }

    if (today != null) {
        if (today.pop >= 50 || today.rainSum >= 2) out += t.tipUmbrella
        if (c(today.max) >= 38) out += t.tipHot
        if (c(today.min) <= 8) out += t.tipCold
        if (today.uv >= 6) out += t.tipUv
        if (kmh(today.windMax) >= 40) out += t.tipWind
    }
    if ((b.air?.aqi ?: 0) > 60) out += t.tipAir
    if ((b.air?.dust ?: 0.0) > 100) out += t.tipDust
    if (out.isEmpty()) out += t.tipNice
    return out
}

private fun hourLabel(iso: String, t: T, first: Boolean): String =
    if (first) t.now else iso.substringAfter('T').take(5)

private fun clock(iso: String): String = iso.substringAfter('T', "").take(5)
