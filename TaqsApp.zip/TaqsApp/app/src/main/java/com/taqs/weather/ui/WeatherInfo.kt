package com.taqs.weather.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Maps WMO weather codes to text, emoji and background gradients. */
object WeatherInfo {

    fun describe(code: Int, lang: String): String {
        val ar = lang == "ar"
        return when (code) {
            0 -> if (ar) "صافٍ" else "Clear sky"
            1 -> if (ar) "غالباً صافٍ" else "Mainly clear"
            2 -> if (ar) "غائم جزئياً" else "Partly cloudy"
            3 -> if (ar) "غائم" else "Overcast"
            45, 48 -> if (ar) "ضباب" else "Fog"
            51, 53, 55 -> if (ar) "رذاذ" else "Drizzle"
            56, 57 -> if (ar) "رذاذ متجمد" else "Freezing drizzle"
            61 -> if (ar) "مطر خفيف" else "Light rain"
            63 -> if (ar) "مطر" else "Rain"
            65 -> if (ar) "مطر غزير" else "Heavy rain"
            66, 67 -> if (ar) "مطر متجمد" else "Freezing rain"
            71 -> if (ar) "ثلج خفيف" else "Light snow"
            73 -> if (ar) "ثلج" else "Snow"
            75 -> if (ar) "ثلج كثيف" else "Heavy snow"
            77 -> if (ar) "حبيبات ثلج" else "Snow grains"
            80 -> if (ar) "زخات مطر خفيفة" else "Light showers"
            81 -> if (ar) "زخات مطر" else "Showers"
            82 -> if (ar) "زخات مطر عنيفة" else "Violent showers"
            85, 86 -> if (ar) "زخات ثلج" else "Snow showers"
            95 -> if (ar) "عاصفة رعدية" else "Thunderstorm"
            96, 99 -> if (ar) "عاصفة رعدية مع برَد" else "Thunderstorm with hail"
            else -> if (ar) "غير معروف" else "Unknown"
        }
    }

    fun emoji(code: Int, isDay: Boolean = true): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1 -> if (isDay) "🌤️" else "🌙"
        2 -> if (isDay) "⛅" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    fun gradient(code: Int, isDay: Boolean): Brush {
        val (a, b) = when {
            code in listOf(95, 96, 99) -> Color(0xFF37474F) to Color(0xFF12202B)
            code in listOf(61, 63, 65, 66, 67, 80, 81, 82, 51, 53, 55, 56, 57) ->
                if (isDay) Color(0xFF546E7A) to Color(0xFF263238) else Color(0xFF263238) to Color(0xFF0D1519)
            code in listOf(71, 73, 75, 77, 85, 86) -> Color(0xFF78909C) to Color(0xFF455A64)
            code in listOf(45, 48) -> Color(0xFF8D9BA5) to Color(0xFF5B6770)
            code == 3 || code == 2 ->
                if (isDay) Color(0xFF5C8DB8) to Color(0xFF2F5878) else Color(0xFF1C2B45) to Color(0xFF0B1220)
            else ->
                if (isDay) Color(0xFF2E8BE8) to Color(0xFF1558A8) else Color(0xFF14213D) to Color(0xFF050B1A)
        }
        return Brush.verticalGradient(listOf(a, b))
    }

    fun isSevere(code: Int) = code in listOf(95, 96, 99)
    fun isHeavyRain(code: Int) = code in listOf(65, 82, 67)
    fun isSnow(code: Int) = code in listOf(71, 73, 75, 77, 85, 86)
}
