package com.taqs.weather.ui

/** In-app translations so the user can switch Arabic/English without restarting. */
class T(val lang: String) {
    private val ar get() = lang == "ar"
    private fun s(a: String, e: String) = if (ar) a else e

    val appName = s("طقس", "Taqs")
    val now = s("الآن", "Now")
    val today = s("اليوم", "Today")
    val tomorrow = s("غداً", "Tomorrow")
    val feelsLike = s("المحسوسة", "Feels like")
    val high = s("العظمى", "High")
    val low = s("الصغرى", "Low")
    val hourly = s("التوقعات بالساعة (٤٨ ساعة)", "Hourly forecast (48h)")
    val daily15 = s("توقعات ١٥ يوماً", "15-day forecast")
    val details = s("التفاصيل", "Details")
    val humidity = s("الرطوبة", "Humidity")
    val wind = s("الرياح", "Wind")
    val gusts = s("هبّات الرياح", "Gusts")
    val pressure = s("الضغط", "Pressure")
    val cloud = s("الغيوم", "Cloud cover")
    val uv = s("الأشعة فوق البنفسجية", "UV index")
    val rain = s("الأمطار", "Rain")
    val rainChance = s("احتمال المطر", "Rain chance")
    val sunrise = s("الشروق", "Sunrise")
    val sunset = s("الغروب", "Sunset")
    val airQuality = s("جودة الهواء", "Air quality")
    val tips = s("نصائح اليوم", "Today's tips")
    val updated = s("آخر تحديث", "Updated")
    val offline = s("أنت غير متصل — يعرض آخر بيانات محفوظة", "Offline — showing last saved data")
    val loading = s("جارٍ التحميل…", "Loading…")
    val retry = s("إعادة المحاولة", "Retry")
    val errorLoad = s("تعذّر تحميل الطقس. تحقق من الاتصال.", "Couldn't load weather. Check your connection.")
    val noPlace = s("اختر مدينة لعرض الطقس", "Pick a city to see the weather")
    val useGps = s("استخدم موقعي", "Use my location")
    val search = s("ابحث عن مدينة", "Search city")
    val searchHint = s("اكتب اسم المدينة…", "Type a city name…")
    val noResults = s("لا توجد نتائج", "No results")
    val favorites = s("المدن المفضلة", "Favorite cities")
    val noFavs = s("لا توجد مدن مفضلة بعد", "No favorites yet")
    val addFav = s("إضافة للمفضلة", "Add to favorites")
    val removeFav = s("إزالة من المفضلة", "Remove from favorites")
    val settings = s("الإعدادات", "Settings")
    val units = s("الوحدات", "Units")
    val temperature = s("درجة الحرارة", "Temperature")
    val windSpeed = s("سرعة الرياح", "Wind speed")
    val appearance = s("المظهر", "Appearance")
    val themeSystem = s("حسب النظام", "System")
    val themeLight = s("فاتح", "Light")
    val themeDark = s("داكن", "Dark")
    val language = s("اللغة", "Language")
    val notifications = s("الإشعارات", "Notifications")
    val dailyNotif = s("ملخص الطقس اليومي", "Daily weather summary")
    val dailyNotifTime = s("وقت الإشعار", "Notification time")
    val alertsNotif = s("تنبيهات الطقس القاسي", "Severe weather alerts")
    val alertsDesc = s("عواصف، أمطار غزيرة، حرارة شديدة، رياح قوية", "Storms, heavy rain, extreme heat, strong wind")
    val permNeeded = s("يلزم السماح بالإشعارات", "Notification permission needed")
    val about = s("حول التطبيق", "About")
    val aboutText = s("بيانات الطقس من Open-Meteo.com", "Weather data by Open-Meteo.com")
    val home = s("الرئيسية", "Home")
    val places = s("المدن", "Cities")
    val locationDenied = s("لم يتم السماح بالوصول للموقع", "Location permission denied")
    val locationFail = s("تعذّر تحديد الموقع", "Couldn't get your location")
    val back = s("رجوع", "Back")
    val myLocation = s("موقعي", "My location")
    val celsius = "°C"
    val fahrenheit = "°F"
    val arabic = "العربية"
    val english = "English"

    fun windUnitLabel(u: String) = when (u) {
        "mph" -> "mph"
        "ms" -> "m/s"
        else -> s("كم/س", "km/h")
    }

    fun tempSym(u: String) = if (u == "f") "°F" else "°C"

    fun aqiLabel(aqi: Int?) = when {
        aqi == null -> "—"
        aqi <= 20 -> s("جيدة جداً", "Very good")
        aqi <= 40 -> s("جيدة", "Good")
        aqi <= 60 -> s("متوسطة", "Moderate")
        aqi <= 80 -> s("سيئة", "Poor")
        aqi <= 100 -> s("سيئة جداً", "Very poor")
        else -> s("خطيرة", "Hazardous")
    }

    fun uvLabel(uv: Double) = when {
        uv < 3 -> s("منخفض", "Low")
        uv < 6 -> s("متوسط", "Moderate")
        uv < 8 -> s("مرتفع", "High")
        uv < 11 -> s("مرتفع جداً", "Very high")
        else -> s("شديد", "Extreme")
    }

    fun compass(deg: Int): String {
        val ar8 = listOf("شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب")
        val en8 = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        val i = (((deg % 360) + 22.5) / 45).toInt() % 8
        return if (ar) ar8[i] else en8[i]
    }

    fun weekday(dow: Int): String { // 1=Mon..7=Sun (java.time)
        val a = listOf("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
        val e = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        return (if (ar) a else e)[(dow - 1).coerceIn(0, 6)]
    }

    fun month(m: Int): String {
        val a = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
        val e = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        return (if (ar) a else e)[(m - 1).coerceIn(0, 11)]
    }

    // ---- tips -------------------------------------------------------------
    val tipUmbrella = s("☂️ خذ مظلة معك، احتمال المطر مرتفع", "☂️ Take an umbrella — rain is likely")
    val tipHot = s("🥵 الجو حار جداً، اشرب الماء وتجنب الشمس وقت الظهيرة", "🥵 Very hot — stay hydrated and avoid midday sun")
    val tipCold = s("🧥 الجو بارد، ارتدِ ملابس دافئة", "🧥 It's cold — dress warmly")
    val tipUv = s("🧴 الأشعة فوق البنفسجية عالية، استخدم واقي الشمس", "🧴 High UV — use sunscreen")
    val tipWind = s("💨 رياح قوية، انتبه خارج المنزل", "💨 Strong wind — take care outdoors")
    val tipAir = s("😷 جودة الهواء سيئة، قلّل النشاط الخارجي", "😷 Poor air quality — limit outdoor activity")
    val tipNice = s("😊 طقس لطيف، يوم مناسب للخروج", "😊 Pleasant weather — great day to go out")
    val tipDust = s("🌫️ احتمال غبار، ضع كمامة إن لزم", "🌫️ Dust possible — wear a mask if needed")

    // ---- notifications ----------------------------------------------------
    val notifDailyTitle = s("طقس اليوم", "Today's weather")
    val alertStorm = s("⛈️ تنبيه: عاصفة رعدية متوقعة", "⛈️ Alert: thunderstorm expected")
    val alertRain = s("🌧️ تنبيه: أمطار غزيرة متوقعة", "🌧️ Alert: heavy rain expected")
    val alertHeat = s("🔥 تنبيه: حرارة شديدة متوقعة", "🔥 Alert: extreme heat expected")
    val alertWind = s("💨 تنبيه: رياح قوية متوقعة", "💨 Alert: strong wind expected")
    val alertSnow = s("❄️ تنبيه: ثلوج متوقعة", "❄️ Alert: snow expected")
}
