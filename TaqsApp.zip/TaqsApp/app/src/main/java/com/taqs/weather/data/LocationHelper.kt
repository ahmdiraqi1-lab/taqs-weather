package com.taqs.weather.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale

class LocationHelper(private val context: Context) {

    /** Returns the device location as a [Place], or null if unavailable. */
    @SuppressLint("MissingPermission")
    suspend fun current(lang: String): Place? {
        val client = LocationServices.getFusedLocationProviderClient(context)
        val fresh = try {
            client.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                CancellationTokenSource().token
            ).await()
        } catch (e: Exception) {
            null
        }
        val loc = fresh ?: try {
            client.lastLocation.await()
        } catch (e: Exception) {
            null
        }
        if (loc == null) return null

        val name = withContext(Dispatchers.IO) { reverse(loc.latitude, loc.longitude, lang) }
        return Place(
            name = name ?: if (lang == "ar") "موقعي" else "My location",
            country = "",
            lat = loc.latitude,
            lon = loc.longitude,
            isGps = true
        )
    }

    @Suppress("DEPRECATION")
    private fun reverse(lat: Double, lon: Double, lang: String): String? = try {
        Geocoder(context, Locale.forLanguageTag(lang))
            .getFromLocation(lat, lon, 1)
            ?.firstOrNull()
            ?.let { it.locality ?: it.subAdminArea ?: it.adminArea }
    } catch (e: Exception) {
        null
    }
}
