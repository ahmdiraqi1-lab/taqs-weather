package com.taqs.weather.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.taqs.weather.data.LocationHelper
import com.taqs.weather.data.Place
import com.taqs.weather.data.Prefs
import com.taqs.weather.data.Settings
import com.taqs.weather.data.WeatherBundle
import com.taqs.weather.data.WeatherRepository
import com.taqs.weather.work.Scheduler
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val settings: Settings = Settings(),
    val place: Place? = null,
    val bundle: WeatherBundle? = null,
    val favorites: List<Place> = emptyList(),
    val loading: Boolean = false,
    val error: Boolean = false,
    val offline: Boolean = false,
    val results: List<Place> = emptyList(),
    val searching: Boolean = false,
    val searched: Boolean = false,
    val message: String? = null,
    val ready: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val repo = WeatherRepository()
    private val locator = LocationHelper(app)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var loadJob: Job? = null
    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            val s = prefs.settings.first()
            val place = prefs.currentPlace.first()
            val favs = prefs.favorites.first()
            val cache = prefs.cached.first()
            _state.update {
                it.copy(
                    settings = s,
                    place = place,
                    favorites = favs,
                    bundle = if (cache != null && place != null && cache.place.key == place.key) cache else null,
                    ready = true
                )
            }
            if (place != null) refresh()
        }
        // keep settings in sync
        viewModelScope.launch {
            prefs.settings.collect { s -> _state.update { it.copy(settings = s) } }
        }
        viewModelScope.launch {
            prefs.favorites.collect { f -> _state.update { it.copy(favorites = f) } }
        }
    }

    fun refresh() {
        val place = _state.value.place ?: return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = false) }
            try {
                val b = repo.load(place, _state.value.settings)
                prefs.saveCache(b)
                _state.update { it.copy(bundle = b, loading = false, offline = false, error = false) }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                val has = _state.value.bundle != null
                _state.update { it.copy(loading = false, offline = has, error = !has) }
            }
        }
    }

    fun selectPlace(p: Place) {
        viewModelScope.launch {
            prefs.setCurrentPlace(p)
            _state.update { it.copy(place = p, bundle = null, results = emptyList(), searched = false) }
            refresh()
            Scheduler.sync(getApplication(), _state.value.settings)
        }
    }

    fun useGps() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = false) }
            val lang = _state.value.settings.lang
            val p = locator.current(lang)
            if (p == null) {
                _state.update { it.copy(loading = false, message = T(lang).locationFail) }
            } else {
                selectPlace(p)
            }
        }
    }

    fun onLocationDenied() {
        _state.update { it.copy(message = T(it.settings.lang).locationDenied) }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }

    fun showMessage(m: String) = _state.update { it.copy(message = m) }

    // ---- search -----------------------------------------------------------

    fun search(q: String) {
        searchJob?.cancel()
        if (q.trim().length < 2) {
            _state.update { it.copy(results = emptyList(), searching = false, searched = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            _state.update { it.copy(searching = true) }
            val r = try {
                repo.search(q.trim(), _state.value.settings.lang)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                emptyList()
            }
            _state.update { it.copy(results = r, searching = false, searched = true) }
        }
    }

    // ---- favorites --------------------------------------------------------

    fun toggleFavorite(p: Place) {
        viewModelScope.launch {
            val cur = _state.value.favorites
            val next = if (cur.any { it.key == p.key }) cur.filterNot { it.key == p.key }
            else cur + p.copy(isGps = false)
            prefs.setFavorites(next)
        }
    }

    // ---- settings ---------------------------------------------------------

    fun setTemp(v: String) {
        _state.update { it.copy(settings = it.settings.copy(tempUnit = v)) }
        viewModelScope.launch { prefs.setTemp(v) }
        refresh()
    }

    fun setWind(v: String) {
        _state.update { it.copy(settings = it.settings.copy(windUnit = v)) }
        viewModelScope.launch { prefs.setWind(v) }
        refresh()
    }

    fun setTheme(v: String) = viewModelScope.launch { prefs.setTheme(v) }
    fun setLang(v: String) = viewModelScope.launch { prefs.setLang(v) }

    fun setDaily(enabled: Boolean) = viewModelScope.launch {
        prefs.setNotif(enabled)
        Scheduler.sync(getApplication(), prefs.settings.first())
    }

    fun setDailyHour(h: Int) = viewModelScope.launch {
        prefs.setNotifHour(h)
        Scheduler.sync(getApplication(), prefs.settings.first())
    }

    fun setAlerts(enabled: Boolean) = viewModelScope.launch {
        prefs.setAlerts(enabled)
        Scheduler.sync(getApplication(), prefs.settings.first())
    }
}
