package com.taqs.weather.data

import retrofit2.http.GET
import retrofit2.http.Query

interface OpenMeteoApi {

    @GET("https://api.open-meteo.com/v1/forecast")
    suspend fun forecast(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String,
        @Query("hourly") hourly: String,
        @Query("daily") daily: String,
        @Query("timezone") timezone: String,
        @Query("forecast_days") days: Int,
        @Query("temperature_unit") tempUnit: String,
        @Query("wind_speed_unit") windUnit: String
    ): ForecastResponse

    @GET("https://air-quality-api.open-meteo.com/v1/air-quality")
    suspend fun air(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String,
        @Query("timezone") timezone: String
    ): AirResponse

    @GET("https://geocoding-api.open-meteo.com/v1/search")
    suspend fun search(
        @Query("name") name: String,
        @Query("count") count: Int,
        @Query("language") language: String,
        @Query("format") format: String
    ): GeoResponse
}
