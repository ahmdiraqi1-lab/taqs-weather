package com.taqs.weather.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.taqs.weather.data.Place

@Composable
fun PlacesScreen(
    st: UiState,
    t: T,
    onSearch: (String) -> Unit,
    onSelect: (Place) -> Unit,
    onToggleFav: (Place) -> Unit,
    onGps: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; onSearch(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(t.searchHint) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = ""; onSearch("") }) {
                    Icon(Icons.Filled.Close, null)
                }
            }
        )

        Row(
            Modifier.fillMaxWidth().clickable { onGps() }.padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.MyLocation, null, tint = MaterialTheme.colorScheme.primary)
            Text(
                t.useGps, modifier = Modifier.padding(start = 12.dp),
                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold
            )
        }
        HorizontalDivider()

        if (st.searching) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(0.dp)) {
            val showingSearch = query.trim().length >= 2

            if (showingSearch) {
                if (st.searched && st.results.isEmpty() && !st.searching) {
                    item { Text(t.noResults, Modifier.padding(vertical = 20.dp)) }
                }
                items(st.results, key = { it.key }) { p ->
                    PlaceRow(p, st.favorites.any { it.key == p.key }, { onSelect(p) }, { onToggleFav(p) })
                }
            } else {
                item {
                    Text(
                        t.favorites, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 18.dp, bottom = 6.dp)
                    )
                }
                if (st.favorites.isEmpty()) {
                    item { Text(t.noFavs, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                items(st.favorites, key = { it.key }) { p ->
                    PlaceRow(p, true, { onSelect(p) }, { onToggleFav(p) })
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(p: Place, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.LocationOn, null, tint = MaterialTheme.colorScheme.secondary)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(p.name, fontWeight = FontWeight.SemiBold)
            if (p.country.isNotBlank()) {
                Text(p.country, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        IconButton(onClick = onFav) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                tint = if (fav) androidx.compose.ui.graphics.Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
    HorizontalDivider()
}
