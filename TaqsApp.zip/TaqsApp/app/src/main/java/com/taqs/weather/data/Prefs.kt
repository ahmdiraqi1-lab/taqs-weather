package com.taqs.weather.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.taqsStore by preferencesDataStore(name = "taqs_prefs")

class Prefs(context: Context) {

    private val store = context.applicationContext.taqsStore
    private val gson = Gson()

    private object K {
        val TEMP = stringPreferencesKey("temp_unit")
        val WIND = stringPreferencesKey("wind_unit")
        val THEME = stringPreferencesKey("theme")
        val LANG = stringPreferencesKey("lang")
        val NOTIF = booleanPreferencesKey("notif_enabled")
        val NOTIF_HOUR = intPreferencesKey("notif_hour")
        val ALERTS = booleanPreferencesKey("alerts_enabled")
        val PLACE = stringPreferencesKey("current_place")
        val FAVS = stringPreferencesKey("favorites")
        val CACHE = stringPreferencesKey("cache")
        val ASKED = booleanPreferencesKey("asked_location")
        val LAST_ALERT = stringPreferencesKey("last_alert_key")
    }

    val settings: Flow<Settings> = store.data.map { p ->
        Settings(
            tempUnit = p[K.TEMP] ?: "c",
            windUnit = p[K.WIND] ?: "kmh",
            theme = p[K.THEME] ?: "system",
            lang = p[K.LANG] ?: "ar",
            notifEnabled = p[K.NOTIF] ?: false,
            notifHour = p[K.NOTIF_HOUR] ?: 7,
            alertsEnabled = p[K.ALERTS] ?: true
        )
    }

    suspend fun setTemp(v: String) { store.edit { it[K.TEMP] = v } }
    suspend fun setWind(v: String) { store.edit { it[K.WIND] = v } }
    suspend fun setTheme(v: String) { store.edit { it[K.THEME] = v } }
    suspend fun setLang(v: String) { store.edit { it[K.LANG] = v } }
    suspend fun setNotif(v: Boolean) { store.edit { it[K.NOTIF] = v } }
    suspend fun setNotifHour(v: Int) { store.edit { it[K.NOTIF_HOUR] = v } }
    suspend fun setAlerts(v: Boolean) { store.edit { it[K.ALERTS] = v } }

    // ---- places -----------------------------------------------------------

    val currentPlace: Flow<Place?> = store.data.map { p ->
        p[K.PLACE]?.let { runCatching { gson.fromJson(it, Place::class.java) }.getOrNull() }
    }

    suspend fun setCurrentPlace(place: Place) {
        store.edit { it[K.PLACE] = gson.toJson(place) }
    }

    val favorites: Flow<List<Place>> = store.data.map { p ->
        p[K.FAVS]?.let {
            runCatching {
                gson.fromJson<List<Place>>(it, object : TypeToken<List<Place>>() {}.type)
            }.getOrNull()
        } ?: emptyList()
    }

    suspend fun setFavorites(list: List<Place>) {
        store.edit { it[K.FAVS] = gson.toJson(list) }
    }

    // ---- offline cache ----------------------------------------------------

    val cached: Flow<WeatherBundle?> = store.data.map { p ->
        p[K.CACHE]?.let { runCatching { gson.fromJson(it, WeatherBundle::class.java) }.getOrNull() }
    }

    suspend fun saveCache(b: WeatherBundle) {
        store.edit { it[K.CACHE] = gson.toJson(b) }
    }

    // ---- misc -------------------------------------------------------------

    val askedLocation: Flow<Boolean> = store.data.map { it[K.ASKED] ?: false }
    suspend fun setAskedLocation() { store.edit { it[K.ASKED] = true } }

    val lastAlertKey: Flow<String> = store.data.map { it[K.LAST_ALERT] ?: "" }
    suspend fun setLastAlertKey(v: String) { store.edit { it[K.LAST_ALERT] = v } }
}
