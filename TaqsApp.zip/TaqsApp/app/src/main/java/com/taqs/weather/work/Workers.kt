package com.taqs.weather.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.taqs.weather.data.Prefs
import com.taqs.weather.data.WeatherRepository
import com.taqs.weather.ui.T
import com.taqs.weather.ui.WeatherInfo
import kotlinx.coroutines.flow.first
import kotlin.math.roundToInt

/** Posts the once-a-day weather summary. */
class DailyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        val s = prefs.settings.first()
        if (!s.notifEnabled) return Result.success()
        val place = prefs.currentPlace.first() ?: return Result.success()
        return try {
            val b = WeatherRepository().load(place, s)
            val t = T(s.lang)
            val today = b.daily.firstOrNull() ?: return Result.success()
            val sym = t.tempSym(s.tempUnit)
            val text = "${WeatherInfo.emoji(today.code)} ${WeatherInfo.describe(today.code, s.lang)} · " +
                "${t.high} ${today.max.roundToInt()}$sym / ${t.low} ${today.min.roundToInt()}$sym" +
                (if (today.pop >= 30) " · ${t.rainChance} ${today.pop}%" else "")
            Notifier.post(applicationContext, Notifier.CH_DAILY, 1001, "${t.notifDailyTitle} — ${place.name}", text)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

/** Checks the next 24h for severe conditions and alerts once per condition per day. */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        val s = prefs.settings.first()
        if (!s.alertsEnabled) return Result.success()
        val place = prefs.currentPlace.first() ?: return Result.success()
        return try {
            // fetch in metric so thresholds are unit-independent
            val b = WeatherRepository().load(place, s.copy(tempUnit = "c", windUnit = "kmh"))
            val next = b.hourly.take(24)
            val t = T(s.lang)

            val msg: String? = when {
                next.any { WeatherInfo.isSevere(it.code) } -> t.alertStorm
                next.any { WeatherInfo.isSnow(it.code) } -> t.alertSnow
                next.any { WeatherInfo.isHeavyRain(it.code) } -> t.alertRain
                next.any { it.temp >= 45.0 } -> t.alertHeat
                next.any { it.wind >= 60.0 } -> t.alertWind
                else -> null
            }
            if (msg != null) {
                val key = "${place.key}|${b.daily.firstOrNull()?.date}|$msg"
                if (prefs.lastAlertKey.first() != key) {
                    Notifier.post(applicationContext, Notifier.CH_ALERTS, 1002, place.name, msg)
                    prefs.setLastAlertKey(key)
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
