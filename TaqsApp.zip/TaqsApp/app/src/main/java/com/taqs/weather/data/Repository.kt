package com.taqs.weather.data

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class WeatherRepository {

    private val api: OpenMeteoApi = Retrofit.Builder()
        .baseUrl("https://api.open-meteo.com/")
        .client(
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
        )
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(OpenMeteoApi::class.java)

    private fun <T> List<T>?.at(i: Int): T? = this?.getOrNull(i)

    /** Loads 15 days of forecast + next 48 hours + air quality for [place]. */
    suspend fun load(place: Place, s: Settings): WeatherBundle = coroutineScope {
        val tUnit = if (s.tempUnit == "f") "fahrenheit" else "celsius"
        val wUnit = when (s.windUnit) {
            "mph" -> "mph"
            "ms" -> "ms"
            else -> "kmh"
        }

        val forecastCall = async {
            api.forecast(
                lat = place.lat,
                lon = place.lon,
                current = CURRENT,
                hourly = HOURLY,
                daily = DAILY,
                timezone = "auto",
                days = 15,
                tempUnit = tUnit,
                windUnit = wUnit
            )
        }
        val airCall = async {
            try {
                api.air(place.lat, place.lon, AIR, "auto")
            } catch (e: Exception) {
                null
            }
        }

        val f = forecastCall.await()
        val c = f.current ?: error("missing current")
        val h = f.hourly ?: error("missing hourly")
        val d = f.daily ?: error("missing daily")

        val current = CurrentWeather(
            time = c.time ?: "",
            temp = c.temperature_2m ?: 0.0,
            feelsLike = c.apparent_temperature ?: c.temperature_2m ?: 0.0,
            humidity = (c.relative_humidity_2m ?: 0.0).roundToInt(),
            code = (c.weather_code ?: 0.0).toInt(),
            isDay = (c.is_day ?: 1.0) >= 1.0,
            cloud = (c.cloud_cover ?: 0.0).roundToInt(),
            pressure = c.pressure_msl ?: 0.0,
            wind = c.wind_speed_10m ?: 0.0,
            windDir = (c.wind_direction_10m ?: 0.0).roundToInt(),
            gusts = c.wind_gusts_10m ?: 0.0,
            precipitation = c.precipitation ?: 0.0
        )

        // hourly: start from the current hour, keep 48 points
        val times = h.time.orEmpty()
        val curHour = current.time.take(13)
        var start = times.indexOfFirst { it.take(13) >= curHour }
        if (start < 0) start = 0
        val hours = (start until minOf(start + 48, times.size)).map { i ->
            HourPoint(
                time = times[i],
                temp = h.temperature_2m.at(i) ?: 0.0,
                pop = (h.precipitation_probability.at(i) ?: 0.0).roundToInt(),
                code = (h.weather_code.at(i) ?: 0.0).toInt(),
                isDay = (h.is_day.at(i) ?: 1.0) >= 1.0,
                wind = h.wind_speed_10m.at(i) ?: 0.0
            )
        }

        val dates = d.time.orEmpty()
        val days = dates.indices.map { i ->
            DayPoint(
                date = dates[i],
                code = (d.weather_code.at(i) ?: 0.0).toInt(),
                max = d.temperature_2m_max.at(i) ?: 0.0,
                min = d.temperature_2m_min.at(i) ?: 0.0,
                sunrise = d.sunrise.at(i) ?: "",
                sunset = d.sunset.at(i) ?: "",
                uv = d.uv_index_max.at(i) ?: 0.0,
                rainSum = d.precipitation_sum.at(i) ?: 0.0,
                pop = (d.precipitation_probability_max.at(i) ?: 0.0).roundToInt(),
                windMax = d.wind_speed_10m_max.at(i) ?: 0.0
            )
        }

        val air = airCall.await()?.current?.let {
            AirQuality(it.european_aqi?.roundToInt(), it.pm2_5, it.pm10, it.dust)
        }

        WeatherBundle(
            place = place,
            current = current,
            hourly = hours,
            daily = days,
            air = air,
            tempUnit = s.tempUnit,
            windUnit = s.windUnit,
            fetchedAt = System.currentTimeMillis()
        )
    }

    suspend fun search(query: String, lang: String): List<Place> {
        val r = api.search(query, 12, lang, "json")
        return r.results.orEmpty().mapNotNull {
            val name = it.name ?: return@mapNotNull null
            val lat = it.latitude ?: return@mapNotNull null
            val lon = it.longitude ?: return@mapNotNull null
            Place(
                name = name,
                country = listOfNotNull(it.admin1, it.country).joinToString(", "),
                lat = lat,
                lon = lon
            )
        }
    }

    private companion object {
        const val CURRENT = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day," +
            "precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m," +
            "wind_direction_10m,wind_gusts_10m"
        const val HOURLY = "temperature_2m,precipitation_probability,weather_code," +
            "wind_speed_10m,is_day"
        const val DAILY = "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset," +
            "uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max"
        const val AIR = "european_aqi,pm2_5,pm10,dust"
    }
}
