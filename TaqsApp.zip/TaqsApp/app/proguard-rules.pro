# Keep Gson / Retrofit model classes
-keep class com.taqs.weather.data.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
